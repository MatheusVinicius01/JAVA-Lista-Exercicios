package MatheusVinicius;

import java.util.Scanner;

public class MVPN38 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN38 - Confirmar saída com 's'     *");
		System.out.println("***********************************************");

		System.out.println("*Programa*");

		Scanner sc = new Scanner(System.in);

		char resp;

		do {
			System.out.print("Deseja sair? (s/n): ");
			resp = sc.next().toLowerCase().charAt(0);
		} while (resp != 's');
		System.out.println("Saindo...");

	}
}
