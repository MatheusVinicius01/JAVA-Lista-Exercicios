package MatheusVinicius;

import java.util.Scanner;

public class MVPN19 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN19 - Verificar número primo      *");
		System.out.println("***********************************************");
		
		System.out.println("*Programa*");
		
		Scanner Captura = new Scanner(System.in);
        System.out.print("Digite um número: ");
        
        int n = Captura.nextInt();
        boolean primo = true;
        
        if (n <= 1) primo = false;
        for (int i = 2; i <= n / 2; i++) {
            if (n % i == 0) {
                primo = false;
                break;
            }
        }
        
        System.out.println(primo ? "É primo" : "Não é primo");
		
	}
}
