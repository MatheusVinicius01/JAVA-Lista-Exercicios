package MatheusVinicius;

import java.util.Scanner;

public class MVPN25 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN25 - Tabuada com while           *");
		System.out.println("***********************************************");
		
		System.out.println("*Programa*");	

		 Scanner sc = new Scanner(System.in);
		 
	        System.out.print("Digite um número: ");
	        int n = sc.nextInt(), i = 1;
	        while (i <= 10) {
	            System.out.println(n + " x " + i + " = " + (n * i));
	            i++;
	        }
	        
	}
}
