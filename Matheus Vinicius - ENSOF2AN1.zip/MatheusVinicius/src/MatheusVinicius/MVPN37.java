package MatheusVinicius;

import java.util.Scanner;

public class MVPN37 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN37 - Soma até múltiplo de 10     *");
		System.out.println("***********************************************");

		System.out.println("*Programa*");

		Scanner sc = new Scanner(System.in);
		
		int soma = 0, n;
		
		do {
			System.out.print("Digite um número: ");
			n = sc.nextInt();
			soma += n;
		} while (n % 10 != 0);
		System.out.println("Soma total: " + soma);

	}
}
