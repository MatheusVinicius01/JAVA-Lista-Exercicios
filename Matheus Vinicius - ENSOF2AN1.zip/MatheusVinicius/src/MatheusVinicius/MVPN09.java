package MatheusVinicius;

import java.util.Scanner;

public class MVPN09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("*************************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359               *");
		System.out.println("* Classe MVPN09 - Ordem crescente (três números)*");
		System.out.println("*************************************************");
		
		System.out.println("**Programa**");

		Scanner Captura = new Scanner(System.in);
        int a, b, c;
        System.out.print("Digite o primeiro número: ");
        a = Captura.nextInt();
        System.out.print("Digite o segundo número: ");
        b = Captura.nextInt();
        System.out.print("Digite o terceiro número: ");
        c = Captura.nextInt();

        int menor, meio, maior;
        if (a <= b && a <= c) {
            menor = a;
            if (b <= c) {
                meio = b; maior = c;
            } else {
                meio = c; maior = b;
            }
        } else if (b <= a && b <= c) {
            menor = b;
            if (a <= c) {
                meio = a; maior = c;
            } else {
                meio = c; maior = a;
            }
        } else {
            menor = c;
            if (a <= b) {
                meio = a; maior = b;
            } else {
                meio = b; maior = a;
            }
        }
        
        System.out.println("Ordem crescente: " + menor + ", " + meio + ", " + maior);
		
	}
}
