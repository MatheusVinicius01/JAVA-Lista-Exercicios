package MatheusVinicius;

import java.util.Scanner;

public class MVPN36 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN36 - Contagem regressiva         *");
		System.out.println("***********************************************");

		System.out.println("*Programa*");

		int i = 10;

		do {
			System.out.println(i);
			i--;
		} while (i >= 1);

	}
}
