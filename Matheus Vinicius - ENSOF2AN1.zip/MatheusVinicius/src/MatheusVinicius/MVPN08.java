package MatheusVinicius;

import java.util.Scanner;

public class MVPN08 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN08 - Login simples               *");
		System.out.println("***********************************************");
		
		System.out.println("**Programa** ");
		
		Scanner Captura = new Scanner(System.in);
        System.out.print("Usuário: ");
        String usuario = Captura.next();
        System.out.print("Senha: ");
        String senha = Captura.next();
        if (usuario.equals("admin") && senha.equals("1234"))
            System.out.println("Login bem-sucedido!");
        else
            System.out.println("Usuário ou senha incorretos.");
		
	}
}
