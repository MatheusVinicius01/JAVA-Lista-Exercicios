package MatheusVinicius;

import java.util.Scanner;

public class MVPN16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN16 - Contagem regressiva         *");
		System.out.println("***********************************************");
		
		System.out.println("*Programa*");
		
		for (int i = 10; i >= 1; i--)
            System.out.println(i);

	}
}
