package MatheusVinicius;

import java.util.Scanner;

public class MVPN06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN06 - Múltiplo de 3 e/ou 5        *");
		System.out.println("***********************************************");
		
		System.out.println("Programa: ");
		
		 Scanner Captura = new Scanner(System.in);
	        System.out.print("Digite um número: ");
	        int n = Captura.nextInt();
	        if (n % 3 == 0 && n % 5 == 0)
	            System.out.println("Múltiplo de 3 e 5");
	        else if (n % 3 == 0)
	            System.out.println("Múltiplo de 3");
	        else if (n % 5 == 0)
	            System.out.println("Múltiplo de 5");
	        else
	            System.out.println("Não é múltiplo de 3 nem de 5");
		
	}

}
