package MatheusVinicius;

import java.util.Scanner;

public class MVPN40 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("************************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359              *");
		System.out.println("* Classe MVPN40 -Ler números e mostrar o maior *");
		System.out.println("* (até digitar negativo)                       *");
		System.out.println("************************************************");

		System.out.println("*Programa*");

		Scanner sc = new Scanner(System.in);
		
		int n, maior = Integer.MIN_VALUE;
		
		do {
			System.out.print("Digite um número (negativo para sair): ");
			n = sc.nextInt();
			if (n > maior && n >= 0)
				maior = n;
		} while (n >= 0);
		
		System.out.println("Maior número digitado: " + maior);

	}
}
