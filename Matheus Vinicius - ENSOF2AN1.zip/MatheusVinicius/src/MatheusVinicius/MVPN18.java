package MatheusVinicius;

import java.util.Scanner;

public class MVPN18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN18 - Múltiplos de 3 entre 1 e 30 *");
		System.out.println("***********************************************");
		
		System.out.println("*Programa*");
		
		for (int i = 3; i <= 30; i += 3)
            System.out.println(i);
		
	}
}
