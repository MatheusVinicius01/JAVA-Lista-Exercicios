package MatheusVinicius;

import java.util.Scanner;

public class MVPN11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN11 - Contar de 1 a 10            *");
		System.out.println("***********************************************");
		
		System.out.println("*Programa*");

		for (int i = 1; i <= 10; i++)
            System.out.println(i);
		
	}
}
