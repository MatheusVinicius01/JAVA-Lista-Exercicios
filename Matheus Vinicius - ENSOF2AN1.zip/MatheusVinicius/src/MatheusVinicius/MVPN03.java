package MatheusVinicius;

import java.util.Scanner;

public class MVPN03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN03 - Maior de dois números       *");
		System.out.println("***********************************************");
		
		System.out.println("Programa: ");
		
		Scanner Captura = new Scanner(System.in);
        System.out.print("Digite o primeiro número: ");
        int a = Captura.nextInt();
        System.out.print("Digite o segundo número: ");
        int b = Captura.nextInt();
        if (a > b)
            System.out.println("Maior: " + a);
        else if (b > a)
            System.out.println("Maior: " + b);
        else
            System.out.println("São iguais.");
		
	}

}
