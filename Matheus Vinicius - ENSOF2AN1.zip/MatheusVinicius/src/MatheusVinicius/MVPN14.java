package MatheusVinicius;

import java.util.Scanner;

public class MVPN14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN14 - Números pares de 0 a 50     *");
		System.out.println("***********************************************");
		
		System.out.println("*Programa*");

		for (int i = 0; i <= 50; i += 2)
            System.out.println(i);

	}
}
