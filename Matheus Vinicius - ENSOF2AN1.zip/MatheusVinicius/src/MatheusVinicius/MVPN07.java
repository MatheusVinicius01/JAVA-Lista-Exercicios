package MatheusVinicius;

import java.util.Scanner;

public class MVPN07 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN07 - Triângulo válido            *");
		System.out.println("***********************************************");
		
		System.out.println("Programa: ");
	
		Scanner Captura = new Scanner(System.in);
        System.out.print("Lado 1: ");
        int a = Captura.nextInt();
        System.out.print("Lado 2: ");
        int b = Captura.nextInt();
        System.out.print("Lado 3: ");
        int c = Captura.nextInt();

        if (a + b > c && a + c > b && b + c > a)
            System.out.println("Triângulo válido");
        else
            System.out.println("Triângulo inválido");
		
	}	

}
