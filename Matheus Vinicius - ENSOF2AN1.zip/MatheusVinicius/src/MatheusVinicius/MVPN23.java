package MatheusVinicius;

import java.util.Scanner;

public class MVPN23 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN23 - Senha correta               *");
		System.out.println("***********************************************");

        System.out.println("*Programa*");

		Scanner sc = new Scanner(System.in);

		String senha;

		do {
			System.out.print("Digite a senha: ");
			senha = sc.next();
		} while (!senha.equals("1234"));
		System.out.println("Acesso liberado!");

	}
}
