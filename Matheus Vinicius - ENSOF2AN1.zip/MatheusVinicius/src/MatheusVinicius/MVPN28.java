package MatheusVinicius;

import java.util.Scanner;

public class MVPN28 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("************************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359              *");
		System.out.println("* Classe MVPN28 - Soma dos pares entre 1 e 100 *");
		System.out.println("************************************************");
		
		System.out.println("*Programa*");
		
	    int soma = 0, i = 2;
	    
        while (i <= 100) {
            soma += i;
            i += 2;
        }
        
        System.out.println("Soma dos pares = " + soma);

	}
}
