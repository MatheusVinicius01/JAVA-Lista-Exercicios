package MatheusVinicius;

import java.util.Scanner;

public class MVPN01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN01 - Número positivo ou negativo *");
		System.out.println("***********************************************");
		
		System.out.println("Programa: ");
		
		Scanner Captura = new Scanner(System.in);
        System.out.print("Digite um número: ");
        int n = Captura.nextInt();
        if (n > 0)
            System.out.println("Positivo");
        else if (n < 0)
            System.out.println("Negativo");
        else
            System.out.println("Zero");
		
	}

}
