package MatheusVinicius;

import java.util.Scanner;

public class MVPN29 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN29 - Contar dígitos              *");
		System.out.println("***********************************************");
		
		System.out.println("*Programa*");
		
		Scanner sc = new Scanner(System.in);
        System.out.print("Digite um número positivo: ");
        
        int n = sc.nextInt();
        int cont = 0;
        
        while (n > 0) {
            n /= 10;
            cont++;
        }
        
        System.out.println("Quantidade de dígitos: " + cont);

	}
}
