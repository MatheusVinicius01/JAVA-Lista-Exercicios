package MatheusVinicius;

import java.util.Scanner;

public class MVPN26 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN26 - Número primo com while      *");
		System.out.println("***********************************************");
		
		System.out.println("*Programa*");

		Scanner sc = new Scanner(System.in);
        System.out.print("Digite um número: ");
        
        int n = sc.nextInt();
        boolean primo = n > 1;
        int i = 2;
        
        while (i <= n / 2 && primo) {
            if (n % i == 0) primo = false;
            i++;
        }
        System.out.println(primo ? "É primo" : "Não é primo");
		
	}
}
