package MatheusVinicius;

import java.util.Scanner;

public class MVPN04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN04 - Pode votar?                 *");
		System.out.println("***********************************************");
		
		System.out.println("Programa: ");

		Scanner Captura = new Scanner(System.in);
        System.out.print("Digite sua idade: ");
        int idade = Captura.nextInt();
        if (idade >= 16)
            System.out.println("Pode votar!");
        else
            System.out.println("Não pode votar!");
		
	}
}