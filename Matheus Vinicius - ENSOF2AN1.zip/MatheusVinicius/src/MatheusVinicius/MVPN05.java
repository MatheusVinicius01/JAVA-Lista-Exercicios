package MatheusVinicius;

import java.util.Scanner;

public class MVPN05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN05 - Notas e aprovação           *");
		System.out.println("***********************************************");
		
		System.out.println("Programa: ");
		
		Scanner Captura = new Scanner(System.in);
        System.out.print("Digite a nota: ");
        double nota = Captura.nextDouble();
        if (nota >= 7)
            System.out.println("Aprovado");
        else if (nota >= 5)
            System.out.println("Recuperação");
        else
            System.out.println("Reprovado");
        
	}

}
