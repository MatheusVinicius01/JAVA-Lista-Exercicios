package MatheusVinicius;

import java.util.Scanner;

public class MVPN10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN010 - Ano bissexto               *");
		System.out.println("***********************************************");
		
		System.out.println("*Programa*");
		
		Scanner Captura = new Scanner(System.in);
        System.out.print("Digite o ano: ");
        int ano = Captura.nextInt();
        if ((ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0))
            System.out.println("Ano bissexto");
        else
            System.out.println("Não é bissexto");

	}
}
