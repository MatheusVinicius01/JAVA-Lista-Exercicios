package MatheusVinicius;

import java.util.Scanner;

public class MVPN31 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN31 - Contar de 1 a 10            *");
		System.out.println("***********************************************");

		System.out.println("*Programa*");

		int i = 1;

		do {
			System.out.println(i);
			i++;
		} while (i <= 10);

	}
}
