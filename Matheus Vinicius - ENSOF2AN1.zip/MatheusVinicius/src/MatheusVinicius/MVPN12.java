package MatheusVinicius;

import java.util.Scanner;

public class MVPN12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN12 - Tabuada de um número        *");
		System.out.println("***********************************************");
		
		System.out.println("*Programa*");

		Scanner Captura = new Scanner(System.in);
        System.out.print("Digite um número: ");
        int n = Captura.nextInt();
        for (int i = 1; i <= 10; i++)
            System.out.println(n + " x " + i + " = " + (n * i));
		
	}
}
