package MatheusVinicius;

import java.util.Scanner;

public class MVPN24 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN24 - Número positivo             *");
		System.out.println("***********************************************");
		
		System.out.println("*Programa*");

		Scanner Captura = new Scanner(System.in);
		
        int n;
        
        do {
            System.out.print("Digite um número positivo: ");
            n = Captura.nextInt();
        } while (n <= 0);
        System.out.println("Número aceito: " + n);
		
	}
}
