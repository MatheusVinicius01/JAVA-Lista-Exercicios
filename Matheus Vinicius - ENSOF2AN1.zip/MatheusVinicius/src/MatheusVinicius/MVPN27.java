package MatheusVinicius;

import java.util.Scanner;

public class MVPN27 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("*************************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359               *");
		System.out.println("* Classe MVPN27 - Quantidade de números ímpares *");
		System.out.println("*************************************************");
		
		System.out.println("*Programa*");
		
		Scanner sc = new Scanner(System.in);
		
        int cont = 0, n, i = 0;
        
        while (i < 10) {
            System.out.print("Digite um número: ");
            n = sc.nextInt();
            if (n % 2 != 0) cont++;
            i++;
        }
        
        System.out.println("Quantidade de ímpares: " + cont);
		
	}
}
