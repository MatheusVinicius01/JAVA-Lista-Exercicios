package MatheusVinicius;

import java.util.Scanner;

public class MVPN13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359                         *");
		System.out.println("* Classe MVPN13 - Soma dos 100 primeiros números naturais *");
		System.out.println("***********************************************************");
		
		System.out.println("*Programa*");

		int soma = 0;
        for (int i = 1; i <= 100; i++)
            soma += i;
        System.out.println("Soma = " + soma);
		
	}
}
