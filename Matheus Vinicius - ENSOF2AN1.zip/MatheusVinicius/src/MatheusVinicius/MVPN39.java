package MatheusVinicius;

import java.util.Scanner;

public class MVPN39 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN39 - Validar número entre 1 e 5  *");
		System.out.println("***********************************************");

		System.out.println("*Programa*");

		Scanner sc = new Scanner(System.in);
		int n;
		
		do {
			System.out.print("Digite um número entre 1 e 5: ");
			n = sc.nextInt();
		} while (n < 1 || n > 5);
		System.out.println("Número válido: " + n);

	}
}
