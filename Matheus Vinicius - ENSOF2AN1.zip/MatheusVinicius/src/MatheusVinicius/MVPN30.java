package MatheusVinicius;

import java.util.Scanner;

public class MVPN30 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("***********************************************");
		System.out.println("* Aluno: Matheus Vinicius - 24359             *");
		System.out.println("* Classe MVPN30 - Menu até sair               *");
		System.out.println("***********************************************");

		System.out.println("*Programa*");

		Scanner sc = new Scanner(System.in);

		int op;

		while (true) {
			System.out.println("1 - Mensagem\n2 - Sair");
			op = sc.nextInt();
			if (op == 1)
				System.out.println("Você escolheu a mensagem!");
			else if (op == 2)
				break;
			else
				System.out.println("Opção inválida.");
		}

	}
}
